package org.example.config;

public class AppConfig {
    public static final String DOWNLOAD_PATH="E:\\B tech (CSE)_3013\\CSE 7 sem\\JavaIDM\\Downloads";
}
